# - HEADER -
    # Algoritma Menghitung Keliling Jajar Genjang 
    # Pengguna menginput sebuah alas(a)
    # dan sisi miring jajar genjang(b)

# Deklarasi 
    # float alas(a), sisi_miring_jajar_genjang(b), Keliling(K)

# Deskripsi 
    # INPUT (alas(a), sisi_miring_jajar_genjang(b))
    # SET Keliling(k) = 2 * ( alas(a) + sisi_miring_jajar_genjang(b) )
    # PRINT ( Keliling(k) )



# SET N = 10 
# FOR i in 1...N
    # PRINT "Hello World!"
# ENDFOR 

# INPUT a,b,c
# SET rata-rata = (a+b+c)/3
# IF (rata-rata == a) OR (rata-rata == b), OR (rata-rata == c)
    # PRINT "Simetris"
# ELSEIF 
    # PRINT ("Tidak Simetris")

# ENDIF