for i in range(2, 11, 2):
    print('Angka ke =', i)
