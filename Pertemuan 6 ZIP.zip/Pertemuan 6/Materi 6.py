# for i in range (5):
#     print ("Hai")
    
# for i in range(1,10):
#     print(i)

# Step = 2
# for i in range(1,12,Step):
#     print(i)

# Step = -2
# for i in range(12,1,Step):
#     print(i)

# # START 
# while <stop> :
#     #isi 
#     #isi 
#     #STEP NYA (INI BERSIFAT OPSIONAL)

# bilangan = 0
# positif = False
# while positif == False:
#     bilangan = int(input('Masukkan bilangan positif: '))
#     if bilangan > 0:
#         positif = True
# print(bilangan, 'yang anda masukkan adalah bilangan positif')


# while True:
#     angka = int(input('Masukkan angka (0 untuk berhenti): '))
#     total = angka * 100
#     if angka == 0:
#         print('Program berhenti.')
#         break
#     print("Total angka yang anda jika kali dengan 100 adalah :",total )
#     print("Anda memasukkan: ",angka)

# for angka in range(1,11):
#     if angka % 2 == 0:
#         continue
#     print('bilangan ganjil', angka)

for i in range(2, 11, 2):
    print('Angka ke =', i)


# i = 2
# while i < 11:
#     print('Angka ke =', i)
#     i += 2
