# contoh = "Hello World!"
# contoh2 = "Ini adalah String"
# print(contoh [2])
# print(contoh2[3])

# hewan = ['kucing', 'babi', 'ayam']
# print('babi' in hewan) #True
# print('burung' in hewan) #False

# kata = "program"
# if 'p' in kata:
#     print("'p' ditemukan dalam kata.") # akan ke print 
# else:
#     print("'p' tidak ditemukan.") # Tidak akan ke print

# print(len('HAII')) # 4
# print(len('Halo Hai')) # 8

# kalimat = ("Aku","kamu","dia")
# print(len(kalimat)) #3
data = ("aku adalah guru")
print (data [len(data)-2]) #r huruf dari terakhir ke dua

kata = "Ada"
for i in kata:
    print(i) 

teks = "Murphy"
hasil = ""

for huruf in teks:
    hasil = huruf + hasil 

print("Kebalikannya:", hasil)

teks = ("Lukisan")
print(teks[0:4]) #outputnya Luki