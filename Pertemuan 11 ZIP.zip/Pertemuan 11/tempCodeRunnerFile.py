"""Jawaban No 1"""
# def MenghitungDict(Dictionary):
#     print("key\tvalue\titems")
#     for key,value in Dictionary.items():
#         print(f"{key}\t{value}\t{key}")
# MenghitungDict({1: 10, 2: 20, 3: 30, 4: 40, 5: 50, 6: 60})
