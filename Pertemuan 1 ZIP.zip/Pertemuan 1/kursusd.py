kursusd = 13950
print('Program konversi US$ ke IDR')
print('Kurs saat ini 1 US$ = ',kursusd, 'Rupiah')

jumlahusd =float(input('Masukkan jumlah uang yang mau ditukar ke Rupiah: '))

dalamrupiah = jumlahusd * kursusd

print('Hasil konversi = Rp. ', dalamrupiah)