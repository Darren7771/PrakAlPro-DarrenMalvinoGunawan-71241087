# # if ... : 
# #     if ... :
# #         ...
# #     elif ... : 
# #         ...
# #     else: 
# #         ...
# # else:
# #     ...

# if ... : 
#     if ... :
#         ...
#     elif ... : 
#         ...
#     else: 
#         ...
#     if ... :
#         ...
#     else:
#         ...
#     if... : 
#         ...
#     elif ... : 
#         ...

# else:
#     ...

# if ... : 
#     if ... :
#         ...
#     elif ... : 
#         ...
#     else: 
#         ...
#     if ... :
#         ...
#     else:
#         ...
#     if... : 
#         ...
#     elif ... : 
#         ...
#     elif...:
#         ...
#     elif...:
#         ...
#     else:
#         ...

# else:
#     ...

# for i in range(1,10):
#     if i == 7:
#         break
#     print(i)

# for i in range(1,6):
#     if i == 2:
#         continue
#     print(i)

# for x in range(3):  
#     for y in range(2):  
#         print(f"(x,y) = ({x},{y})")  

# x = 0  
# while x < 3:  
#     y = 0  
#     while y < 2:  
#         print(f"(x,y) = ({x},{y})")  
#         y += 1  
#     x += 1  

# x = 0  
# while x < 3:  
#     for y in range(2):  
#         print(f"(x,y) = ({x},{y})")  
#     x += 1  

for x in range(3):  
    y = 0  
    while y < 2:  
        print(f"(x,y) = ({x},{y})")  
        y += 1  