# # makanan = "Nasi Goreng"
# # minuman = ("Air")
# # jumlah = 17

# # print(minuman, type(minuman)) 

# # proses memasukan data ke dalam variabel
# hariIni = "senin"
# #proses mencetak variabel
# print(hariIni)

# nilai dan tipe data dapat diubah
# Harga = 90
# print(Harga)
# type(Harga)
# Harga = "Sembilan Puluh" #Untuk mengubah nilai 
# print(Harga)             #mencetak nilai harga
# type(Harga)              #cek tipe data variabel harga


# print(1)
# x = 3334
# print(x)

# 7373
# x
# x*7373

# Menggunakan Integer 
# A = 90 
# B = 10
# print ( A + B )

# Menggunakan String 
A = "halo "
B = 3
print( A * B )

# Pertambahan
# Pengurangan
# Bisa mengisi bebas
# Ini semua komentar 

# Ini adalah rumus luas persegi
sisi = 4 
Luas = sisi * 4 
print("Luas Persegi adalah", Luas , "cm")